export class NameRoutes {
   static saveMoney:string = "/saveMoney";  
   static howManyCoins:string = "/howManyCoins";
   static howMuchMoney:string = "/howMuchMoney";
   static quantityCoin:string = "/quantityCoin";
   static currencyAmount:string = "/currencyAmount";
}