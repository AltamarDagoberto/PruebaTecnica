export const ADDMONEY = "AUTHENTICATED";
export const GETMONEY = "LOGOUT";