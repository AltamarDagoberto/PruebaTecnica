import AppRouter from "./app/routes/AppRouter";

function App() {
  return (
    <AppRouter />
  );
}

export default App;
